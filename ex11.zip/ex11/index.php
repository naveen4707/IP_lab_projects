<!DOCTYPE html>
<html>

<head>
    <title>Online Shopping</title>
</head>

<body>

<h2>Online Shopping Order</h2>

<form method="POST" action="order.php">

    Customer Name:
    <input type="text" name="customer_name" required>
    <br><br>

    Product Name:
    <input type="text" name="product_name" required>
    <br><br>

    Quantity:
    <input type="number" name="quantity" required>
    <br><br>

    Price:
    <input type="number" name="price" required>
    <br><br>
    
    Totalamount:
    <input type="number" name="total_amount" required>
    <br><br>
    
    Order_Date:
    <input type="text" name="order_date" required>
    <br><br>
    
    Address:
    <input type="text" name="address" required>
    <br><br>
    
    <input type="submit" value="Place Order">

</form>

</body>
</html>