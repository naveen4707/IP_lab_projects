<?php

$conn = new mysql("localhost", "root", "mysql", "shopping_db");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $customer_name = trim($_POST["customer_name"]);
    $product_name = trim($_POST["product_name"]);
    $quantity = trim($_POST["quantity"]);
    $price = trim($_POST["price"]);
    $total_amount = trim($_POST["total_amount"]);
    $order_date = trim($_POST["order_date"]);
    $address = trim($_POST["address"]);

    $sql = "INSERT INTO orders
            (customer_name, product_name, quantity, price, total_amount, order_date, address)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ssid",
        $customer_name,
        $product_name,
        $quantity,
        $price,
        $total_amount,
        
        $address
    );

    if ($stmt->execute()) {
        echo "<h3>Order placed successfully!</h3>";
    } else {
        echo "<h3>Error: " . $stmt->error . "</h3>";
    }

    $stmt->close();
}



$sql = "SELECT * FROM orders";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>

<head>
    <title>Online Shopping Orders</title>
</head>

<body>

<h2>Order Details</h2>

<table border="1" cellpadding="10">

<tr>
    <th>Order ID</th>
    <th>Customer Name</th>
    <th>Product Name</th>
    <th>Quantity</th>
    <th>Price</th>
    <th>Total_amount</th>
    <th>Date</th>
    <th>Address</th>
</tr>

<?php


if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        echo "<tr>";

        echo "<td>" . htmlspecialchars($row["id"]) . "</td>";

        echo "<td>" .
             htmlspecialchars($row["customer_name"]) .
             "</td>";

        echo "<td>" .
             htmlspecialchars($row["product_name"]) .
             "</td>";

        echo "<td>" .
             htmlspecialchars($row["quantity"]) .
             "</td>";

        echo "<td>" .
             htmlspecialchars($row["price"]) .
             "</td>";
        echo "<td>" .
             htmlspecialchars($row["total_amount"]) .
             "</td>";
        echo "<td>" .
             htmlspecialchars($row["order_date"]) .
             "</td>";
        
        echo "<td>" .
             htmlspecialchars($row["address"]) .
             "</td>";
        
        echo "</tr>";
    }

} else {

    echo "<tr>";
    echo "<td colspan='5'>No orders found</td>";
    echo "</tr>";
}

$conn->close();

?>

</table>

</body>
</html>