function validateForm(){
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let emailPattern = /^[^]+@[^]+\.[a-z]{2,3}$/;
    let phone = document.getElementById("phone").value;
    let gender = document.querySelector('input[name="gender"]:checked');
    let resume = document.getElementById("resume").value;
    if(!email.match(emailPattern)){
        alert("Please enter a valid email address.");
        return false;
    }
    if(!resume.match(/\.(pdf|doc|docx)$/i)){
        alert("Only PDF/DOC/DOCX allowed.");
        return false;
    }
    if(!validateForm()){
        return false;
    }
    return alert("Form submitted successfully!");
}
