
document.getElementById('naveen').addEventListener('submit', function(event) {
    event.preventDefault();
    const correctAnswers = {
        q1: "HTML",
        q2: "CSS",
        q3: "JavaScript",
        q4: "Central Processing Unit",
        q5: "Hard Disk",
        q6: "//",
        q7: "30",
        q8: "a",
        q9: "const",
        q10: "56"
    };

    const formData = new FormData(this);

    const username = formData.get('username');
    const rollno = formData.get('rollno');

    let score = 0;
    const totalQuestions = 10;

    let reportHTML = `
        <h1> Quiz Evaluation Report</h1>
        <p><strong>Name:</strong> ${username}</p>
        <p><strong>Roll No:</strong> ${rollno}</p>
        <hr>
        <ul>
    `;
    for (let i = 1; i <= totalQuestions; i++) {

        const qKey = 'q' + i;
        const userAns = formData.get(qKey);
        const correctAns = correctAnswers[qKey];

        const isCorrect = userAns === correctAns;

        if (isCorrect) {
            score++;
        }

        reportHTML += `
            <li style="margin-bottom: 15px;">
                <strong>Question ${i}</strong><br>

                Your Answer:
                <span class="${isCorrect ? 'correct' : 'incorrect'}">
                    ${userAns}
                </span>

                ${
                    !isCorrect
                    ? `<br>
                       <small style="color: gray;">
                           Correct Answer: ${correctAns}
                       </small>`
                    : `<br>
                       <span class="correct">✓ Correct</span>`
                }
            </li>
        `;
    }

    reportHTML += `</ul><hr>`;
    const percentage = (score / totalQuestions) * 100;

    reportHTML += `
        <h2>Final Score: ${score} / ${totalQuestions}</h2>
        <h3>Percentage: ${percentage}%</h3>
    `;
    if (percentage >= 80) {
        reportHTML += `
            <p class="correct">
                 Excellent! Great job!
            </p>
        `;
    } else if (percentage >= 50) {
        reportHTML += `
            <p style="color: orange; font-weight: bold;">
                 Good job! Keep practicing.
            </p>
        `;
    } else {
        reportHTML += `
            <p class="incorrect">
                 Keep practicing and try again!
            </p>
        `;
    }
    this.style.display = 'none';
    const resultDiv = document.getElementById('result-container');

    resultDiv.innerHTML = reportHTML;
    resultDiv.style.display = 'block';
});