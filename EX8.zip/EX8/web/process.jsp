<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Process Student Details</title>
</head>

<body>

    <h1>JSP Page Processing</h1>

    <%
        String id = request.getParameter("userid");

        String pass = request.getParameter("password");

        String name = request.getParameter("Name");

        String cardno = request.getParameter("Creditcardno");
        String mail = request.getParameter("Email");
        String phoneno = request.getParameter("Phonenumber");
    %>

    <h2>Welcome, <%= name %>!</h2>

    <h3>Employee Details</h3>

    <p>
        <strong>Name:</strong>
        <%= name %>
    </p>

    <p>
        <strong>Userid:</strong>
        <%= id %>
    </p>

    <p>
        <strong>Password:</strong>
        <%= pass %>
    </p>

    <p>
        <strong>Credit Card no:</strong>
        <%= cardno %>
    </p>
    <p>
        <strong>Email:</strong>
        <%= mail %>
    </p>
    <p>
        <strong>Phone number:</strong>
        <%= phoneno%>
    </p>

    <br>

    <a href="index.html">Back to Home</a>

</body>
</html>