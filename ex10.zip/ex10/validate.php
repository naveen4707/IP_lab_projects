<?php 
$errors = array();
$username = $_POST["username"];
$email = $_POST["email"]; 
$phone = $_POST["phone"]; 
$password = $_POST["password"]; 
$card = $_POST["card"]; 
$items = $_POST["items"];  
if (!preg_match("/^[A-Za-z]+$/", $username)) { 
    $errors[] = "Username must contain only letters."; }
if (!preg_match("/^[\w.-]+@[\w.-]+\.\w{2,4}$/", $email)) {
    $errors[] = "Invalid email format."; }
if (!preg_match("/^[0-9]{10}$/", $phone)) {
    $errors[] = "Phone number must contain exactly 10 digits."; }
if (!preg_match("/^[A-Za-z0-9@#$]{6,}$/", $password)) {
    $errors[] = "Password must contain at least 6 characters."; } 
if (!preg_match("/^[0-9]{16}$/", $card)) { 
    $errors[] = "Credit card number must contain exactly 16 digits."; }
if (count($errors) == 0) {
    echo "<h2>Registration Successful!</h2>";
    echo "<p>All entered details are valid.</p>"; 
    echo "<h3>Entered Details:</h3>";
    echo "Username: " . $username . "<br>";
    echo "Email: " . $email . "<br>";
    echo "Phone Number: " . $phone . "<br>";
    echo "Password: " . $password . "<br>";
    echo "Credit Card Number: " . $card . "<br>";
    echo "Purchased Items: " . $items . "<br>"; }
 else { 
     echo "<h2>Validation Errors</h2>";
     echo "<ul>";
     foreach ($errors as $error) {
         echo "<li>" . $error . "</li>"; }
     echo "</ul>";
     echo "<br>";
     echo "<a href='index.php'>Go Back</a>"; } 
?>