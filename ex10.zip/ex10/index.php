<!DOCTYPE html>
<html>
<head>
    <title>Server Side Validation</title>

    <style>
        body {
            font-family: Arial;
            background-color: #f2f2f2;
        }
        .container {
            width: 400px;
            margin: 50px auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px gray;
        }
       h2 {
            text-align: center;
        }
        input {
            width: 95%;
            padding: 10px;
            margin: 8px 0 15px;
        }
        input[type="submit"] {
            width: 100%;
            background-color: #333;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>Registration Form</h2>

    <form action="validate.php" method="post">
        <label>Username:</label>
        <input type="text" name="username" required>
        <label>Email:</label>
        <input type="text" name="email" required>
        <label>Phone Number:</label>
        <input type="text" name="phone" required>
        <label>Password:</label>
        <input type="password" name="password" required>
        <label>Credit Card Number:</label>
        <input type="text" name="card" required>
        <label>Purchased items</label>
        <input type="text" name="items" required>
        <input type="submit" value="Register">
    </form>
</div>

</body>
</html>
